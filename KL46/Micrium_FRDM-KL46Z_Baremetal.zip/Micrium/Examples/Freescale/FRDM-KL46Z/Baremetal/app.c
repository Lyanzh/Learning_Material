/*
*********************************************************************************************************
*                                              EXAMPLE CODE
*
*                          (c) Copyright 2003-2014; Micrium, Inc.; Weston, FL
*
*               All rights reserved.  Protected by international copyright laws.
*               Knowledge of the source code may NOT be used to develop a similar product.
*               Please help us continue to provide the Embedded community with the finest
*               software available.  Your honesty is greatly appreciated.
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*
*                                            EXAMPLE CODE
*
*                                        Freescale Kinetis KL40
*                                               on the
*                                        Freescale FRDM-KL46Z
*                                          Evaluation Board
*
* Filename      : app.c
* Version       : V1.00
* Programmer(s) : JPB
*                 SB
*********************************************************************************************************
*/

/*
*********************************************************************************************************
*                                             INCLUDE FILES
*********************************************************************************************************
*/

#include  <app_cfg.h>
#include  <includes.h>


/*
*********************************************************************************************************
*                                            LOCAL DEFINES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/

static  CPU_INT08U    App_LCD_Dig1;
static  CPU_INT08U    App_LCD_Dig2;
static  CPU_INT08U    App_LCD_Dig3;
static  CPU_INT08U    App_LCD_Dig4;

static  CPU_INT08U    App_TSI_SliderPosMm;
static  CPU_INT08U    App_TSI_SliderPosPct;


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                                main()
*
* Description : This is the standard entry point for C code.  It is assumed that your code will call
*               main() once you have performed all necessary initialization.
*
* Argument(s) : none.
*
* Return(s)   : none.
*
* Caller(s)   : This the main standard entry point.
*
* Note(s)     : none.
*********************************************************************************************************
*/

int  main (void)
{
    int i;

#if (CPU_CFG_NAME_EN == DEF_ENABLED)
    CPU_ERR     cpu_err;
#endif

    CPU_Init();                                                 /* Initialize the CPU abstraction layer.                */

#if (CPU_CFG_NAME_EN == DEF_ENABLED)
    CPU_NameSet((CPU_CHAR *)"MKL46Z256VLL4",
                (CPU_ERR  *)&cpu_err);
#endif

    CPU_IntDis();                                               /* Disable all interrupts.                              */

    BSP_Init();                                                 /* Start BSP initialization.                            */
    BSP_LCD_Init();                                             /* Initialize the seven-segment display panel.          */

    CPU_IntEn();                                                /* Enable all interrupts.                               */

#ifdef  CPU_CFG_INT_DIS_MEAS_EN
    CPU_IntDisMeasMaxCurReset();
#endif

                                                                /* Timing for the LEDs, LCD, and Slider:                */
                                                                /* Slider : Every 50 ms                                 */
                                                                /* LEDs   : RED, 200 ms dly, Green, 200ms dly, ...      */
                                                                /* LCD    : Every 400 ms                                */
    while(DEF_ON) {
        BSP_LED_Toggle(BSP_LED_RED);

        BSP_LCD_Write(App_LCD_Dig1,
                      App_LCD_Dig2,
                      App_LCD_Dig3,
                      App_LCD_Dig4,
                      BSP_LCD_OPT_NONE);

                                                                /* Read the slider periodically for 200 ms              */
        for (i = 4; i > 0; i--) {
            BSP_TSI_SliderRead(&App_TSI_SliderPosMm,
                               &App_TSI_SliderPosPct);

            BSP_Timer_Dly(50u, 0u);
        }
                                                                /* Toggle the green LED.                                */
        BSP_LED_Toggle(BSP_LED_GREEN);

                                                                /* Read the slider periodically for 200 ms              */
        for (i = 4; i > 0; i--) {
            BSP_TSI_SliderRead(&App_TSI_SliderPosMm,
                               &App_TSI_SliderPosPct);

            BSP_Timer_Dly(50u, 0u);
        }
    }
}
